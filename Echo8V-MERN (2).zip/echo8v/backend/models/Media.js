import mongoose from "mongoose";

const mediaSchema = new mongoose.Schema(
  {
    name: String,
    url: String,
    key: String,
    mime: String,
    size: Number,
  },
  { timestamps: true },
);

export default mongoose.model("Media", mediaSchema);
